<?php $__env->startSection('admin-title', 'Bookings'); ?>

<?php $__env->startSection('big-name'); ?>
    <small>Bookings </small>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-style'); ?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css"/>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css"/>
 
 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <?php if(Session::has('sms')): ?>
            <div class="alert alert-info">
               <?php echo e(Session::get('sms')); ?>

                <a href="#" data-dismiss="alert" class="close">×</a>
            </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Error Alert</strong>. 
                <a href="#" data-dismiss="alert" class="close">×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="widget-box">
                <div class="widget-title">
                    
                    <h5>Bookings</h5>
                </div>
                <div class="table-responsive widget-content nopadding">
                    <table class="data-table table table-bordered table-striped table-hover with-check">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Booked By</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>code</th>
                                <th>Pay Status</th>
                                <th>Seat Number(s)</th>
                                <th>Amount Paid</th>
                                <th>Gender</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($booking->user->email); ?></td>
                                <td><?php echo e($booking->email); ?></td>
                                <td><?php echo e($booking->phone); ?></td>
                                <td><?php echo e($booking->bk_ref); ?></td>
                                <td><?php echo e($booking->getPay()); ?></td>
                                <td><?php echo e($booking->seat); ?></td>
                                <td>&#x20A6 <?php echo e(number_format($booking->amount * $booking->seat_num)); ?></td>
                                <td><?php echo e($booking->gender); ?></td>
                                <td><?php echo e($booking->created_at->format('Y-m-d | g:i A')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                No Bookings for this Route yet.
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>  
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $('.checkbox_all').click(function () {
            $('input.checkbox_delete').prop('checked', this.checked);
            getIds();
        });

        $('.checkbox_delete').change(function () {
            getIds();
        })

        function getIds()
        {
            var ids = [];
            $('.checkbox_delete').each(function () {
                if($(this).is(":checked")) {
                    ids.push($(this).val());
                }
            });

            $('#ids').val(ids.join());
        }
    </script>
     
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
<script src="/authmin/js/unicorn.tables.js"></script>
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>