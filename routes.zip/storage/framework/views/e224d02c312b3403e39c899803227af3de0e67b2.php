<?php $__env->startSection('big-name'); ?>
    Create New Camp
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
   <div class="col-xs-12">
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Error Alert</strong>. 
            <a href="#" data-dismiss="alert" class="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="widget-box">
            <div class="widget-title">
                <span class="icon">
                    <i class="fa fa-align-justify"></i>                                 
                </span>
                <h5>Camp Details</h5>
            </div>
            <div class="widget-content nopadding">
                <form action="<?php echo e(route('camps.store')); ?>" method="post" class="form-horizontal">
                    <div class="form-group" <?php echo e($errors->has('name') ? ' has-error' : ''); ?>>
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Name:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <input type="text" placeholder="Name of Orientation Camp" name="camp"  class="form-control input-sm" />
                        </div>
                    </div>
                    <div class="form-group" <?php echo e($errors->has('details') ? ' has-error' : ''); ?>>
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Details:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <textarea name="details" placeholder="Additiional Details" class="form-control" rows="5"></textarea>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success btn-sm">Add Camp</button>
                    </div>
                    <?php echo e(csrf_field()); ?>

                </form>
            </div>
        </div>                      
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>