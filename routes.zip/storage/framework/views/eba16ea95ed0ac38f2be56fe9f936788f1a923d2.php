<?php $__env->startSection('styles'); ?>
    <script src="/tabstyle/js/modernizr.custom.js"></script>
    <style>
        h2 {
          text-align: center;
        }

        table caption {
            padding: .5em 0;
        }

        @media  screen and (max-width: 767px) {
          table caption {
            border-bottom: 1px solid #ddd;
          }
        }

        .p {
          text-align: center;
          padding-top: 140px;
          font-size: 14px;
        }
    </style>
    <script type="text/javascript" src="/aju/assets/fonts/all.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
My Bookings | AjuwayaTravels
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section id="categories-homepage">
    <div class="container-fluid">
        <div class="row">
            <h2>My Bookings</h2>

            <div class="container">
              <div class="row">
                <div class="col-xs-12">
                  <div class="table-responsive">
                        <table summary="This table shows how to create responsive tables using Bootstrap's default functionality" class="table table-bordered table-hover">
                          <caption class="text-center">All Bookings 
                          <thead>
                            <tr>
                              <th>S/N</th>
                              <th>Email</th>
                              <th>Phone</th>
                              <th>Ref</th>
                              <th>No. of Seats</th>
                              <th>Status</th>
                              <th>Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                              <td><?php echo e($loop->iteration); ?></td>
                              <td><?php echo e($booking->email); ?></td>
                              <td><?php echo e($booking->phone); ?></td>
                              <td><?php echo e($booking->bk_ref); ?></td>
                              <td><?php echo e($booking->seat_num); ?></td>
                              <td><?php echo e($booking->getPay()); ?></td>
                              <td><?php echo e($booking->created_at->format('l jS \\of F Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                No Bookings Yet
                            </tr>
                            <?php endif; ?>
                          </tbody>
                          <tfoot>
                          </tfoot>
                        </table>
                      </div><!--end of .table-responsive-->
                </div>
              </div>
            </div>
        </div>
    </div>

    <br>
    <br>
    <br>
    <br>
    <br>
</section>
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>