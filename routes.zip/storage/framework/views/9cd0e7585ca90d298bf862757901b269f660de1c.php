<?php $__env->startSection('big-name'); ?>
    <small style="color: #21b121">Bookings for Route "<?php echo e($route->location->state); ?> to <?php echo e($route->camp->name); ?> (<?php echo e($route->camp->details); ?>)"</small>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <?php if(Session::has('sms')): ?>
            <div class="alert alert-info">
               <?php echo e(Session::get('sms')); ?>

                <a href="#" data-dismiss="alert" class="close">×</a>
            </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Error Alert</strong>. 
                <a href="#" data-dismiss="alert" class="close">×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            

            <div class="widget-box">
                <div class="widget-title">
                    <span class="icon with-checkbox">
                        <input type="checkbox" class="checkbox_all" id="title-checkbox" name="title-checkbox" />
                    </span>
                    <h5>Users that have booked this route</h5>
                </div>
                <div class="widget-content nopadding">
                    <table class="table table-bordered table-striped table-hover with-check">
                        <thead>
                            <tr>
                                <th><i class="fa fa-resize-vertical"></i></th>
                                
                                <th>#</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Pay Status</th>
                                <th>Seat Number(s)</th>
                                <th>Gender</th>
                                <th>Date</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><input type="checkbox" class="checkbox_delete" name="entries_to_delete[]" value="<?php echo e($route->id); ?>" /></td>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($route->email); ?></td>
                                <td><?php echo e($route->phone); ?></td>
                                <td><?php echo e($route->getPay()); ?></td>
                                <td><?php echo e($route->seat); ?></td>
                                <td><?php echo e($route->gender); ?></td>
                                <td><?php echo e($route->created_at->format('F, M j ')); ?></td>
                                <td><?php echo e($route->created_at->format('g:i A')); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                No Bookings for this Route yet.
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>  
                                              
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $('.checkbox_all').click(function () {
            $('input.checkbox_delete').prop('checked', this.checked);
            getIds();
        });

        $('.checkbox_delete').change(function () {
            getIds();
        })

        function getIds()
        {
            var ids = [];
            $('.checkbox_delete').each(function () {
                if($(this).is(":checked")) {
                    ids.push($(this).val());
                }
            });

            $('#ids').val(ids.join());

        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>