<?php $__env->startSection('big-name'); ?>
    Orientation Camps
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="row">
    <div class="col-xs-12">
        <?php if(Session::has('sms')): ?>
        <div class="alert alert-success">
           <?php echo e(Session::get('sms')); ?>

            <a href="#" data-dismiss="alert" class="close">×</a>
        </div>
        <?php endif; ?>
        <div class="alert alert-info">
            <strong>Info</strong>. 
            
            <ul>
                <li style="list-style: none">Once an <strong>Orientation camp</strong> record is deleted, all <strong>routes</strong> that have that camp would also be deleted.</li>
            </ul>
        </div>
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Error Alert</strong>. 
            <a href="#" data-dismiss="alert" class="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <span class="heady">
            <div class="form-actions">
                <a href="<?php echo e(route('camps.create')); ?>" type="submit" class="btn btn-success btn-sm">Add Camp</a>
            </div>
        </span>

        <div class="widget-box">
            <div class="widget-title">
                <span class="icon with-checkbox">
                    <input type="checkbox" class="checkbox_all" id="title-checkbox" name="title-checkbox" />
                </span>
                <h5>Orientation Camps</h5>
            </div>
            <div class="widget-content nopadding">
                <table class="table table-bordered table-striped table-hover with-check">
                    <thead>
                        <tr>
                            <th><i class="fa fa-resize-vertical"></i></th>
                            
                            <th>#</th>
                            <th>Camp Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $camps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><input type="checkbox" class="checkbox_delete" name="entries_to_delete[]" value="<?php echo e($camp->id); ?>" /></td>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($camp->name); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button data-toggle="dropdown" class="btn btn-xs btn-red dropdown-toggle">Options <span class="caret"></span></button>
                                    <ul class="dropdown-menu ">
                                        <li>
                                            <form method="POST" style=" display: inline; padding-left: 2.3rem" action="<?php echo e(route('camps.destroy', $camp->id)); ?>"
                                                onsubmit="return confirm('Are you sure?');">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <?php echo e(csrf_field()); ?>


                                            <button class="btn btn-xs btn-danger">Delete</button>
                                            </form>
                                        </li>
                                    </ul>
                                </div> 
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            No Camps Listed yet.
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>  
                                          
            </div>
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $('.checkbox_all').click(function () {
            $('input.checkbox_delete').prop('checked', this.checked);
            getIds();
        });

        $('.checkbox_delete').change(function () {
            getIds();
        })

        function getIds()
        {
            var ids = [];
            $('.checkbox_delete').each(function () {
                if($(this).is(":checked")) {
                    ids.push($(this).val());
                }
            });

            $('#ids').val(ids.join());

        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>