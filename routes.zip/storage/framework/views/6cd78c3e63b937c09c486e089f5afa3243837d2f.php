<div id="sidebar">
    <ul>
        <li class="<?php echo e(Request::is( 'admin/routes') ? ' active' : ''); ?>">
            <a href="<?php echo e(route('routes.index')); ?>"><i class="fa fa-home"></i> <span>Routes</span></a>
        </li>


        <li class="<?php echo e(Request::is( 'admin/bookings') ? ' active' : ''); ?>">
            <a href="<?php echo e(route('booking.index')); ?>"><i class="fa fa-edit"></i> <span>Bookings</span></a>
        </li>

        <li class="<?php echo e(Request::is( 'admin/camps') ? ' active' : ''); ?>">
            <a href="<?php echo e(route('camps.index')); ?>"><i class="fa fa-cogs"></i> <span>Camps</span></a>
        </li>
        
        
    </ul>
</div>