 <footer>
        <!-- Copyright Start  -->
        <div id="copyright">
            <div class="container noprint">
                <div class="row">
                    <div class="col-md-12">
                        <div class="site-info center">
                            <p>All Rights Reserved <?php echo e(date('Y')); ?> 
                            
                            </p>
                        </div>                        
                        <div style="display: inline-block;" class="bottom-social-icons social-icon pull-right">  
                            <a class="facebook" target="_blank" href="#"><i class="fab fa-facebook-f"></i></a> 
                            <a class="twitter" target="_blank" href="#"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Copyright End -->
    </footer>