<?php $__env->startSection('admin-style'); ?>
    <link rel="stylesheet" href="/authmin/css/select2.css" />
    <link rel="stylesheet" href="/authmin/datey/date.css" />
    <script src="/authmin/datey/date.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('big-name'); ?>
    Create New Route
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
   <div class="col-xs-12">
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Error Alert</strong>. 
            <a href="#" data-dismiss="alert" class="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="widget-box">
            <div class="widget-title">
                <span class="icon">
                    <i class="fa fa-align-justify"></i>                                 
                </span>
                <h5>Route Details</h5>
            </div>
            <div class="widget-content nopadding">
                <form action="<?php echo e(route('routes.store')); ?>" method="post" class="form-horizontal">
                    <div class="form-group <?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Select State:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <select required name="state" id="sel2">
                                <option value=""></option>
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($location->id); ?>"><?php echo e(ucwords($location->state)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('take_off') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Location:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <input name="take_off" value="<?php echo e(Request::old('take_off') ?: ''); ?>" type="text" placeholder="Take off point in selected state" class="form-control input-sm" />
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('camp') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Destination:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <select required name="camp" id="sel1">
                                <option value=""></option>
                                <?php $__currentLoopData = $camps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($location->id); ?>"><?php echo e(ucwords($location->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('camp') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Status:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <select class="form-control" name="status">
                                <option value="1">Active</option>
                                <option value="0">Inctive</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Price:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <input name="price" value="<?php echo e(Request::old('price') ?: ''); ?>" type="text" onkeydown="return editInput(event)" placeholder="Transport Fare" class="form-control input-sm" />
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('seater') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Bus Seater:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <select name="seater" id="sel1">
                                <option value="">X Seater Bus</option>
                                <option value="15">15</option>
                                <option value="35">35</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group" <?php echo e($errors->has('ref') ? ' has-error' : ''); ?>>
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Ref Code:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <input type="text" name="ref" value="<?php echo e($ref); ?>" readonly class="form-control input-sm" />
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('date') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-md-3 col-lg-2 control-label">Date/Time:</label>
                        <div class="col-sm-9 col-md-9 col-lg-10">
                            <input type="text" value="<?php echo e(Request::old('date') ?: ''); ?>" required name="date" class="form-control input-sm" />
                            <script type="text/javascript">
                                $(function(){
                                    $('*[name=date]').appendDtpicker();
                                });
                            </script>                       
                        </div>
                    </div>       
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success btn-sm">Add Route</button>
                    </div>
                    <?php echo e(csrf_field()); ?>

                </form>
            </div>
        </div>                      
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-scripts'); ?>
    <script src="/authmin/js/select2.min.js"></script>  

<script>
    $("#sel1").select2();
    $("#sel2").select2();
    function editInput(e)
    {
        var chaCode = (e.which) ? e.which : event.keyCode
        if(chaCode > 31 && (chaCode < 48 || chaCode > 57))
            return false
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>