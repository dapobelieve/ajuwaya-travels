<?php $__env->startSection('title'); ?>

Welcome to AjuwayaTravels
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="/aju/assets/css/material-kit.css" type="text/css">
<link rel="stylesheet" href="/aju/assets/css/sweetalert.css" type="text/css">
 <script type="text/javascript" src="/aju/assets/fonts/all.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="categories-homepage">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="section-title">Search Results</h3>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="adds-wrapper results">
                    <div class="item-list">
                        <div class="col-sm-8 add-desc-box">
                          <div class="add-details">
                            <h5 class="add-title"><a href="<?php echo e(route('book.start', ['route' => $route->ref])); ?>">
                               <span class="take-off"><?php echo e($route->location->state); ?></span>  to 
                               <span class="dest"><?php echo e($route->camp->toUp()); ?></span>  </a></h5>
                            <div class="info">
                              <span class="add-type"><?php echo e($route->camp->firstLetter()); ?></span>
                              <span class="date takeoff">
                                <i class="fas fa-clock"></i>
                                
                                <?php echo e($route->takeoff->format('l jS \\of F Y h:i:s A')); ?>

                              </span> -
                              <span class="category takeoff">Takeoff point</span> -
                              <span class="item-location takeoff"><i class="fas fa-map-pin"></i> <?php echo e($route->takeoff()); ?></span>
                            </div>
                            <div class="item_desc">
                              <a href="#">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</a>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-4 price-box">
                          <h2 class="item-price pricy"> &#x20A6 <?php echo e(number_format($route->price)); ?> </h2>
                          <a
                            href="<?php echo e(route('route.details', ['route' => $route->ref])); ?>"
                            class="btn btn-danger btn-sm">
                            <i class="fas fa-info-circle"></i>
                            <span>Details</span>
                        </a> 
                          <a 
                            href="<?php echo e(route('book.start', ['route' => $route->ref])); ?>" 
                            class="btn btn-common center btn-sm"> 
                            <i class="fas fa-bus"></i> 
                            <span>Book</span> 
                        </a> 
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="adds-wrapper results">
                    No Results Found.
                </div>
                <?php endif; ?>
            </div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript" src="/aju/assets/js/material.min.js"></script>
<script type="text/javascript" src="/aju/assets/js/material-kit.js"></script>
<script type="text/javascript" src="/aju/assets/js/jquery.parallax.js"></script>
<script type="text/javascript" src="/aju/assets/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="/aju/assets/js/wow.js"></script>
<script type="text/javascript" src="/aju/assets/js/main.js"></script>
<script type="text/javascript" src="/aju/assets/js/sweetalert.min.js"></script>
<script type="text/javascript">
     <?php if(Session::has('authMsg')): ?>
      swal({
      title: "Alert",
      text: "<?php echo e(Session::get('authMsg')); ?>",
      type: 'warning'
    })
    <?php elseif(Session::has('success')): ?>
      swal({
        title: "<?php echo e(Session::get('title')); ?>",
        text:  "<?php echo e(Session::get('success')); ?>",
        type: 'info'
      })
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>