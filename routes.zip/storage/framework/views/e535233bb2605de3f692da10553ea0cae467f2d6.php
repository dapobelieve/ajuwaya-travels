<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" href="/aju/assets/css/sweetalert.css" type="text/css">
<style>
    .forgot {
        cursor: pointer;
    }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-header" style="background: url(/aju/assets/img/banner1.jpg);">
      <div class="container">
        <div class="row">         
          <div class="col-md-12">
            <div class="breadcrumb-wrapper">
              <h2 class="page-title">Join Us</h2>
            </div>
          </div>
        </div>
      </div>
    </div>


    <!-- Content section Start --> 
    <section id="content">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-sm-offset-4 col-md-4 col-md-offset-4">
            <div class="page-login-form box">
              <h3>
                Login
              </h3>
              <form method="post" action="<?php echo e(route('auth.login')); ?>" role="form" class="login-form">
                <div class="form-group">
                  <div class="input-icon">
                    <i class="icon fa fa-user"></i>
                    <input type="text" value="<?php echo e(Request::old('email') ?: ''); ?>" id="sender-email" class="form-control" name="email" placeholder="Email Address">
                  </div>
                </div> 
                <div class="form-group">
                  <div class="input-icon">
                    <i class="icon fa fa-unlock-alt"></i>
                    <input type="password" name="password" class="form-control" placeholder="Password">
                  </div>
                </div>                  
                <div class="checkbox">
                  <input type="checkbox" id="remember" name="remember" value="" style="float: left;">
                  <label for="remember">Remember me</label>
                </div>
                <button class="btn btn-common log-btn">Sign in</button>
                <?php echo e(csrf_field()); ?>

                    <a href="/redirect/google" class="btn log-btn btn-google">
                        Sign in with Google
                    </a>
                    <a href="<?php echo e(route('auth.register')); ?>" class="btn btn-success log-btn">
                        Create Account
                    </a>
                    <span class="forgot">
                        <a href="<?php echo e(route('forgot.index')); ?>">Forgot Password?</a>
                    </span>
                       
              </form>
              
              
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Content section End -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/aju/assets/js/sweetalert.min.js"></script>
<script type="text/javascript">
     <?php if(Session::has('authMsg')): ?>
      swal({
      title: "Alert",
      text: "<?php echo e(Session::get('authMsg')); ?>",
      type: 'info'
    })
    <?php elseif(Session::has('success')): ?>
      swal({
        title: "<?php echo e(Session::get('title')); ?>",
        text:  "<?php echo e(Session::get('success')); ?>",
        type: 'info'
      })
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>