<div id="sidebar">
    <ul>
        <li class="active"><a href="#"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
        <li>
            <a href="#"><i class="fa fa-signal"></i> <span>Events</span></a>
        </li>
        <li>
            <a href="#"><i class="fa fa-cogs"></i> <span>Gallery</span></a>
        </li>
        <li>
            <a href="#"><i class="fa exit"></i> <span>Logout</span></a>
        </li>
        
    </ul>
</div>