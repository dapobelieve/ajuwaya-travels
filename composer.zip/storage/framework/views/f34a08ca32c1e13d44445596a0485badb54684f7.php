<?php $__env->startSection('admin-style'); ?>
    <link rel="stylesheet" href="/authmin/css/dataTables.bootstrap.css">
    <link rel="stylesheet" href="/authmin/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('big-name'); ?>
    <small>Bookings </small>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <?php if(Session::has('sms')): ?>
            <div class="alert alert-info">
               <?php echo e(Session::get('sms')); ?>

                <a href="#" data-dismiss="alert" class="close">×</a>
            </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Error Alert</strong>. 
                <a href="#" data-dismiss="alert" class="close">×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="widget-box">
                <div class="widget-title">
                    <span class="icon with-checkbox">
                        <input type="checkbox" class="checkbox_all" id="title-checkbox" name="title-checkbox" />
                    </span>
                    <h5>Bookings</h5>
                </div>
                <div class="widget-content nopadding">
                    <table id="dtable" class="table table-bordered table-striped table-hover with-check">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Pay Status</th>
                                <th>Seat Number(s)</th>
                                <th>Gender</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($booking->email); ?></td>
                                <td><?php echo e($booking->phone); ?></td>
                                <td><?php echo e($booking->getPay()); ?></td>
                                <td><?php echo e($booking->seat); ?></td>
                                <td><?php echo e($booking->gender); ?></td>
                                <td><?php echo e($booking->created_at->format('D, M j  @   g:i A')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                No Bookings for this Route yet.
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>  
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $('.checkbox_all').click(function () {
            $('input.checkbox_delete').prop('checked', this.checked);
            getIds();
        });

        $('.checkbox_delete').change(function () {
            getIds();
        })

        function getIds()
        {
            var ids = [];
            $('.checkbox_delete').each(function () {
                if($(this).is(":checked")) {
                    ids.push($(this).val());
                }
            });

            $('#ids').val(ids.join());

        }
    </script>
    <script src="/authmin/js/jquery.dataTables.min.js"></script>
    <script src="/authmin/js/dataTables.bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#dtable').DataTable();
        })
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>