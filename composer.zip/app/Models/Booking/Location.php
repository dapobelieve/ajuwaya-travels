<?php

namespace App\Models\Booking;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    protected $table = 'states';
}
