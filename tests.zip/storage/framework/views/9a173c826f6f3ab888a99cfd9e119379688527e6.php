<?php $__env->startSection('styles'); ?>

    
    <link rel="stylesheet" type="text/css" href="/tabstyle/css/demo.css" />
    <link rel="stylesheet" type="text/css" href="/tabstyle/css/tabs.css" />
    <link rel="stylesheet" type="text/css" href="/tabstyle/css/tabstyles.css" />
    <script src="/tabstyle/js/modernizr.custom.js"></script>
    <script type="text/javascript" src="/aju/assets/fonts/all.js"></script>

    <script>
        window.ajt_model = "<?php echo e($route); ?>";
        window.currUser  = <?php echo e(Auth::user()->id); ?>;
    </script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Booking | AjuwayaTravels
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
    
    <div style="padding: 0.9rem" id="app">

        <router-view name="bookBus"></router-view>
        
        <router-view></router-view>
        
        
    </div>
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="/tabstyle/js/cbpFWTabs.js"></script>
<script>
    (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
            new CBPFWTabs( el );
        });

    })();


</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>