<?php $__env->startSection('content'); ?>

    <div class="page-header" style="background: url(/aju/assets/img/banner1.jpg);">
      <div class="container">
        <div class="row">         
          <div class="col-md-12">
            <div class="breadcrumb-wrapper">
              <h2 class="page-title">Join Us</h2>
            </div>
          </div>
        </div>
      </div>
    </div>


    <!-- Content section Start --> 
    <section id="content">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
            <div class="page-login-form box">
              <h3>
                Register
              </h3>
              <?php if(count($errors) > 0): ?>
                    <strong>Error alert:</strong>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li style="color:red"> * <?php echo e($error); ?> </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
              <?php endif; ?>
              <form role="form" action="<?php echo e(route('auth.register')); ?>" method="post" class="login-form">
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <div class="input-icon">
                    <i class="icon fa fa-envelope"></i>
                    <input type="text" value="<?php echo e(Request::old('email') ?: ''); ?>" class="form-control" name="email" placeholder="Email Address">
                    <?php if($errors->has('email')): ?>
                    <span class="help-block formlert">
                        <?php echo e($errors->first('email')); ?>

                    </span>
                  <?php endif; ?>
                  </div>
                </div>
                <div class="form-group<?php echo e($errors->has('fname') ? ' has-error' : ''); ?>">
                  <div class="input-icon">
                    <i class="icon fa fa-user"></i>
                <div class="form-group<?php echo e($errors->has('fname') ? ' has-error' : ''); ?>">
                    <input type="text" value="<?php echo e(Request::old('fname') ?: ''); ?>" value="<?php echo e(Request::old('fname') ?: ''); ?>" class="form-control" name="fname" placeholder="Full Name">
                    <?php if($errors->has('fname')): ?>
                    <span class="help-block formlert">
                        <?php echo e($errors->first('fname')); ?>

                    </span>
                  <?php endif; ?>
                  </div>
                </div>
                <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                  <div class="input-icon">
                    <i class="icon fa fa-unlock-alt"></i>
                    <input type="password" name="password" class="form-control" placeholder="Password">
                    <?php if($errors->has('password')): ?>
                        <span class="help-block formlert">
                            <?php echo e($errors->first('password')); ?>

                        </span>
                  <?php endif; ?>
                  </div>
                </div>  
                <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                  <div class="input-icon">
                    <i class="icon fa fa-unlock-alt"></i>
                    <input type="password" name="password_confirmation" class="form-control" placeholder="Retype Password">
                  </div>
                </div>                 
                
                <button class="btn btn-common log-btn type="submit ">Register</button>
                <?php echo e(csrf_field()); ?>

                <a href="/redirect/google" style="text-transform: none; border-radius: 2px" class="btn btn-xs  btn-social btn-google">
                    <span class="fa fa-google"></span> Sign up with Google
                </a>
                <a href="/redirect/facebook" style="text-transform: none; border-radius: 2px" class="btn btn-xs  btn-social btn-facebook">
                    <span class="fa fa-facebook"></span> Sign up with Facebook
                </a>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Content section End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>