<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

    <?php echo $__env->make('layout.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer Section Start -->
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Footer Section End -->  
    
    <!-- Go To Top Link -->
    <a href="#" class="back-to-top">
      <i class="fa fa-angle-up"></i>
    </a>



<script type="text/javascript" src="/aju/assets/js/jquery-min.js"></script>      
<script type="text/javascript" src="/aju/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/aju/assets/js/jasny-bootstrap.min.js"></script>

<script src="/aju/assets/js/bootstrap-select.min.js"></script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>